# 👋 Hi, I'm Dong Quy Nguyen

**QA / QC Engineer — Manual Testing | API Testing | SQL Validation | Playwright (Learning)**

📍 Ho Chi Minh City, Vietnam &nbsp;·&nbsp; 📧 quydong1992@gmail.com

---

## 🧑‍💻 About Me

QA Engineer with **10+ years of professional experience**, including **5+ years dedicated to manual QA** for enterprise B2B/EDI platforms.

I specialize in:
- ✅ End-to-end manual testing across enterprise web systems
- ✅ API testing with Postman + backend result verification
- ✅ SQL data validation and troubleshooting (SQL Server)
- ✅ Defect management and release sign-off in Agile/Scrum teams

Currently expanding into **test automation with Playwright + TypeScript** — actively practicing and building projects here on GitHub.

---

## 🛠️ Skills & Tools

**Testing**

![Manual Testing](https://img.shields.io/badge/Manual_Testing-0078D4?style=flat-square)
![API Testing](https://img.shields.io/badge/API_Testing-FF6C37?style=flat-square&logo=postman&logoColor=white)
![Regression](https://img.shields.io/badge/Regression_Testing-0078D4?style=flat-square)
![Integration Testing](https://img.shields.io/badge/Integration_Testing-0078D4?style=flat-square)

**Tools**

![Postman](https://img.shields.io/badge/Postman-FF6C37?style=flat-square&logo=postman&logoColor=white)
![SQL Server](https://img.shields.io/badge/SQL_Server-CC2927?style=flat-square&logo=microsoft-sql-server&logoColor=white)
![Azure DevOps](https://img.shields.io/badge/Azure_DevOps-0078D7?style=flat-square&logo=azure-devops&logoColor=white)
![Playwright](https://img.shields.io/badge/Playwright-2EAD33?style=flat-square&logo=playwright&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=flat-square&logo=typescript&logoColor=white)

**Process**

![Agile](https://img.shields.io/badge/Agile-0052CC?style=flat-square)
![Scrum](https://img.shields.io/badge/Scrum-009FDA?style=flat-square)
![B2B/EDI](https://img.shields.io/badge/B2B%2FEDI-5C2D91?style=flat-square)

---

## 📂 Featured Project

### 🎭 [playwright-practice](https://github.com/quydong1992/playwright-practice)
> Playwright TypeScript practice project — UI automation, locators, assertions, form testing, alerts, navigation, and Page Object Model.

```
tests/
├── 01-login.spec.ts              ← login flow, error handling
├── 02-form.spec.ts               ← inputs, checkboxes, dropdowns
├── 03-locators.spec.ts           ← getByRole, getByText, CSS, nth()
├── 04-assertions.spec.ts         ← toBeVisible, toHaveText, soft assertions
├── 05-navigation.spec.ts         ← back/forward, JS alerts, new tab
└── 06-page-object-model.spec.ts  ← POM pattern with LoginPage class
```

---

## 💼 Work Experience

**QA Engineer** @ TrueCommerce Vietnam *(10/2020 – 03/2026)*
> Manual QA across DiWeb, DiMetrics, BlueCRM — B2B/EDI enterprise platforms. API testing, SQL validation, defect lifecycle management, Agile sprints.

**Senior EDI Mapping Analyst** @ TrueCommerce Vietnam *(08/2014 – 10/2020)*
> Partner onboarding, EDI data mapping, UAT, post-deployment validation for document exchange systems.

---

## 🎯 Career Goal

> **Now:** Reliable Manual Tester — clear test cases, solid defect reports, strong release ownership.
>
> **Next:** Senior Automation QA — Playwright + TypeScript as primary automation stack.

---

*💡 Open to Manual Tester / QA Engineer opportunities in Ho Chi Minh City or remote.*
