const { test, expect } = require('@playwright/test');

test.describe('Register page practice', () => {
  test('should register successfully and show submitted data', async ({ page }) => {
    await page.goto('/');

    // Open lesson 1: Register Page
    await page.getByRole('link', { name: /Bài học 1: Register Page/i }).click();

    const username = `dongtest_${Date.now()}`;
    const email = `dongtest_${Date.now()}@gmail.com`;

    await page.locator('#username').fill(username);
    await page.locator('#email').fill(email);

    // Select gender if radio exists
    const maleRadio = page.locator('input[value="male"]');
    if (await maleRadio.count()) {
      await maleRadio.check();
    }

    // Check some hobbies if available
    for (const hobby of ['reading', 'traveling']) {
      const checkbox = page.locator(`input[value="${hobby}"]`);
      if (await checkbox.count()) {
        await checkbox.check();
      }
    }

    // Fill optional fields only when they exist
    const country = page.locator('#country');
    if (await country.count()) {
      await country.selectOption({ value: 'canada' }).catch(() => {});
    }

    const dob = page.locator('#dob');
    if (await dob.count()) {
      await dob.fill('1992-10-20');
    }

    const bio = page.locator('#bio');
    if (await bio.count()) {
      await bio.fill('I am learning automation testing with Playwright.');
    }

    await page.getByRole('button', { name: /register|submit|đăng ký/i }).click();

    await expect(page.getByText(username)).toBeVisible();
    await expect(page.getByText(email)).toBeVisible();
  });
});
