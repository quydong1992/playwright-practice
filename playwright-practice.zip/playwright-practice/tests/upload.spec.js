const { test, expect } = require('@playwright/test');
const path = require('path');

test.describe('File upload practice', () => {
  test('should upload a sample file', async ({ page }) => {
    await page.goto('/');

    const uploadLesson = page.getByRole('link', { name: /upload|tải lên/i });
    await expect(uploadLesson.first()).toBeVisible();
    await uploadLesson.first().click();

    const fileInput = page.locator('input[type="file"]').first();
    await expect(fileInput).toBeAttached();

    await fileInput.setInputFiles(path.join(__dirname, '../test-data/sample-upload.txt'));

    await expect(page.locator('body')).toContainText(/sample-upload|upload|file|tệp/i);
  });
});
