const { test, expect } = require('@playwright/test');

test.describe('Product cart practice', () => {
  test('should add a product to cart and remove it', async ({ page }) => {
    await page.goto('/');

    const productLesson = page.getByRole('link', { name: /product|cart|sản phẩm|giỏ hàng/i });
    await expect(productLesson.first()).toBeVisible();
    await productLesson.first().click();

    const addButton = page.getByRole('button', { name: /add|thêm/i }).first();
    await expect(addButton).toBeVisible();
    await addButton.click();

    // Verify cart area contains at least one product/price/quantity text.
    await expect(page.locator('body')).toContainText(/cart|giỏ|quantity|số lượng|total|tổng/i);

    const removeButton = page.getByRole('button', { name: /remove|xóa|delete/i }).first();
    if (await removeButton.count()) {
      await removeButton.click();
      await expect(page.locator('body')).not.toContainText(/NaN|undefined/i);
    }
  });
});
