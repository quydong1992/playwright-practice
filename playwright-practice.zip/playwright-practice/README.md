# Playwright Practice

This repository contains basic Playwright automation practice for a Manual Tester who is learning Automation Testing.

## Target role
Manual Tester / QA Tester with basic automation orientation.

## What this repo demonstrates

- Web UI automation with Playwright
- Locators and assertions
- Form testing
- Table/result validation
- File upload testing
- Cart/product flow testing
- Basic API testing
- HTML report generation
- GitHub Actions CI workflow

## Tech stack

- JavaScript
- Playwright Test
- Node.js
- GitHub Actions

## Test scenarios

| Area | File | Purpose |
|---|---|---|
| Register form | `tests/register.spec.js` | Fill form, submit, verify submitted data |
| Product/cart | `tests/cart.spec.js` | Add/remove product and verify cart behavior |
| File upload | `tests/upload.spec.js` | Upload single and multiple files |
| API testing | `tests/api.spec.js` | Verify API status and response body |

## How to run locally

```bash
npm install
npx playwright install
npm test
```

Run with browser visible:

```bash
npm run test:headed
```

Open Playwright UI mode:

```bash
npm run test:ui
```

View HTML report:

```bash
npm run report
```

## Notes

This project is for learning and portfolio purposes. Test cases may need minor selector updates if the demo website changes.
